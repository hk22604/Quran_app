import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBHelper {
  // Made public by removing underscore
  static Future<Database> getDb() async {
    final path = await getDatabasesPath();
    return openDatabase(
      join(path, 'quran_app.db'),
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE resume_reading (
            id INTEGER PRIMARY KEY,
            surah TEXT,
            juzz INTEGER
          )
        ''');
        await db.execute('''
          CREATE TABLE bookmarks (
            id INTEGER PRIMARY KEY,
            surah TEXT,
            ayah INTEGER,
            page INTEGER
          )
        ''');
      },
      version: 1,
    );
  }

  static Future<void> saveResumeReading(String surah, int juzz) async {
    final db = await getDb();
    await db.delete('resume_reading');
    await db.insert('resume_reading', {'surah': surah, 'juzz': juzz});
  }

  static Future<Map<String, dynamic>?> getResumeReading() async {
    final db = await getDb();
    final result = await db.query('resume_reading', limit: 1);
    return result.isNotEmpty ? result.first : null;
  }

  static Future<void> addBookmark(String surah, int ayah, int page) async {
    final db = await getDb();
    await db.insert('bookmarks', {'surah': surah, 'ayah': ayah, 'page': page});
  }

  static Future<List<Map<String, dynamic>>> getBookmarks() async {
    final db = await getDb();
    return db.query('bookmarks');
  }
}
