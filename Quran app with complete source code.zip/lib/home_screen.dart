import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/services.dart';
import 'package:islamic_app/MakkahLiveScreen.dart';
import 'package:islamic_app/MadinahLiveScreen.dart';
// App screens
import 'juzz_index_screen.dart';
import 'prayer_times_screen.dart';
import 'book_mark_screen.dart';
import 'surah_detail_screen.dart';
import 'zakat_calculator_screen.dart';
import 'duas_screen.dart';
import 'islamic_calendar_screen.dart';
import 'tasbih_screen.dart';
import 'names_of_allah_screen.dart';
import 'noorani_qaida_screen.dart';
import 'DownloadedSurahsScreen.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  String islamicDate = '';
  String resumeSurah = 'سورة الأنفال';
  int resumeSurahNumber = 1;
  int resumeJuzz = 1;
  int? resumeAyah;

  int _selectedIndex = 0;
  String? dailyHadith;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final Color primaryColor = const Color(0xFF2E7D32);
  final Color secondaryColor = const Color(0xFF81C784);
  final Color cardColor = const Color(0xFFD0F0C0);

  Color _gradientStart = const Color(0xFF2E7D32);
  Color _gradientEnd = const Color(0xFF81C784);

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(vsync: this, duration: Duration(seconds: 1));
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_fadeController);
    _slideAnimation = Tween<Offset>(begin: Offset(0, 0.1), end: Offset.zero).animate(
        CurvedAnimation(parent: _fadeController, curve: Curves.easeOut));
    _fadeController.forward();

    _loadHijriDate();
    _loadResume();
    _loadDailyHadith();
    _startBackgroundAnimation();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  void _startBackgroundAnimation() async {
    while (mounted) {
      await Future.delayed(const Duration(seconds: 10));
      setState(() {
        _gradientStart = _randomGreenColor();
        _gradientEnd = _randomGreenColor();
      });
    }
  }

  Color _randomGreenColor() {
    final random = Random();
    return Color.fromARGB(
      255,
      100 + random.nextInt(50),
      150 + random.nextInt(100),
      100 + random.nextInt(50),
    );
  }

  void _loadHijriDate() {
    HijriCalendar.setLocal("en");
    final now = HijriCalendar.now();
    setState(() {
      islamicDate = "${now.hDay} ${now.longMonthName} ${now.hYear}";
    });
  }

  Future<void> _loadResume() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      resumeSurah = prefs.getString('last_surah_name') ?? 'سورة الأنفال';
      resumeSurahNumber = prefs.getInt('last_surah') ?? 1;
      resumeJuzz = prefs.getInt('last_juzz') ?? 1;
      resumeAyah = prefs.getInt('last_ayah');
    });
  }

  Future<void> _loadDailyHadith() async {
    final String response = await rootBundle.loadString('assets/hadiths.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      dailyHadith = data[Random().nextInt(data.length)];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildBeautifulDrawer(context),
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: const Text('Al Quran', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        elevation: 0,
      ),
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          FadeTransition(
            opacity: _fadeAnimation,
            child: SlideTransition(
              position: _slideAnimation,
              child: Container(
                color: Colors.white.withOpacity(0.9),
                child: _buildBody(),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: primaryColor,
        unselectedItemColor: Colors.grey,
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() => _selectedIndex = index);
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.view_list), label: 'Juzz'),
          BottomNavigationBarItem(icon: Icon(Icons.bookmark), label: 'Bookmarks'),
        ],
      ),
    );
  }

  Widget _buildAnimatedBackground() {
    return AnimatedContainer(
      duration: const Duration(seconds: 10),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_gradientStart, _gradientEnd],
        ),
      ),
    );
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 1:
        return JuzzIndexScreen();
      case 2:
        return BookmarksScreen();
      default:
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _animatedCard(_buildDateCard()),
            const SizedBox(height: 20),
            _animatedCard(_buildResumeCard(), delay: 200),
            const SizedBox(height: 20),
            _animatedCard(_buildHadithCard(), delay: 400),
            const SizedBox(height: 20),
            _animatedCard(_buildFeatureCards(), delay: 600),
          ],
        );
    }
  }

  Widget _animatedCard(Widget child, {int delay = 0}) {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 500 + delay),
      tween: Tween<double>(begin: 0, end: 1),
      curve: Curves.easeOut,
      builder: (context, value, _) {
        return Opacity(
          opacity: value,
          child: Transform.translate(offset: Offset(0, 50 * (1 - value)), child: child),
        );
      },
    );
  }

  Widget _buildDateCard() {
    return Container(
      decoration: _cardDecoration(),
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(islamicDate, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: primaryColor)),
          const SizedBox(height: 5),
          Text("Today's Islamic Date", style: TextStyle(color: Colors.grey[700])),
          const SizedBox(height: 15),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            onPressed: () {
              Navigator.push(context, _fadeRoute(PrayerTimesScreen()));
            },
            icon: const Icon(Icons.access_time),
            label: const Text("Prayer Times"),
          )
        ],
      ),
    );
  }

  Widget _buildResumeCard() {
    return Container(
      decoration: _cardDecoration(color: cardColor),
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(Icons.menu_book, size: 40, color: primaryColor),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(resumeSurah, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  Text("Juzz - $resumeJuzz", style: TextStyle(fontSize: 14, color: Colors.grey[700])),
                ],
              ),
            ],
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                _fadeRoute(SurahDetailScreen(
                  surahNumber: resumeSurahNumber,
                  surahName: resumeSurah,
                  initialAyah: resumeAyah,
                )),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryColor,
              foregroundColor: Colors.white,
              shape: const StadiumBorder(),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            ),
            child: const Text("Resume"),
          )
        ],
      ),
    );
  }

  Widget _buildHadithCard() {
    if (dailyHadith == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return Container(
      decoration: _cardDecoration(),
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Icon(Icons.auto_stories, color: primaryColor, size: 30),
          const SizedBox(height: 10),
          Text(
            dailyHadith!,
            style: const TextStyle(fontSize: 16, color: Colors.black87),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // ✅ Horizontal scroll row with buttons
  Widget _buildFeatureCards() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _featureCard("Tasbih", "assets/icon/tasbih.png", () {
            Navigator.push(context, _fadeRoute(TasbihScreen()));
          }),
          _featureCard("Makkah Live", "assets/icon/mecca.png", () {
            Navigator.push(context, _fadeRoute(MakkahLiveScreen()));
          }),
          _featureCard("Madina Live", "assets/icon/madinah.png", () {
            Navigator.push(context, _fadeRoute(MadinahLiveScreen()));
          }),
          _featureCard("Names of Allah", "assets/icon/Allah.png", () {
            Navigator.push(context, _fadeRoute(NamesOfAllahScreen()));
          }),
          _featureCard("Noorani Qaida", "assets/icon/Allah.png", () {
            Navigator.push(context, _fadeRoute(NamesOfAllahScreen()));
          }),
        ].map((card) => Padding(
          padding: const EdgeInsets.only(right: 12),
          child: card,
        )).toList(),
      ),
    );
  }

  Widget _featureCard(String title, String iconPath, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 130,
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: _cardDecoration(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(iconPath, height: 40),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }


  BoxDecoration _cardDecoration({Color? color}) {
    return BoxDecoration(
      color: color ?? Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 5)],
    );
  }

  Drawer _buildBeautifulDrawer(BuildContext context) {
    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [primaryColor, secondaryColor],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            Container(
              height: 180,
              width: double.infinity,
              padding: const EdgeInsets.only(left: 20, bottom: 20, top: 40),
              alignment: Alignment.bottomLeft,
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.auto_stories, size: 40, color: Color(0xFF2E7D32)),
                  ),
                  const SizedBox(width: 15),
                  const Text(
                    "Al Quran\nApp",
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                children: [
                  _drawerMenuItem(Icons.menu_book, "Quran", () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 0);
                  }),
                  _drawerMenuItem(Icons.view_list, "Juzz Index", () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 1);
                  }),
                  _drawerMenuItem(Icons.access_time_filled, "Prayer Times", () {
                    Navigator.pop(context);
                    Navigator.push(context, _fadeRoute(PrayerTimesScreen()));
                  }),
                  _drawerMenuItem(Icons.bookmark, "Bookmarks", () {
                    Navigator.pop(context);
                    setState(() => _selectedIndex = 2);
                  }),
                  _drawerMenuItem(Icons.date_range, "Islamic Calendar", () {
                    Navigator.pop(context);
                    Navigator.push(context, _fadeRoute(IslamicCalendarScreen()));
                  }),
                  _drawerMenuItem(Icons.calculate, "Zakat Calculator", () {
                    Navigator.pop(context);
                    Navigator.push(context, _fadeRoute(ZakatCalculatorScreen()));
                  }),
                  _drawerMenuItem(Icons.self_improvement, "Duas & Azkar", () {
                    Navigator.pop(context);
                    Navigator.push(context, _fadeRoute(DuasScreen()));
                  }),
                  _drawerMenuItem(Icons.download_done, "Downloaded Surahs", () {
                    Navigator.pop(context);
                    Navigator.push(context, _fadeRoute(DownloadedSurahsScreen()));
                  }),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(12.0),
              child: Text("© 2025 Islamic App", style: TextStyle(color: Colors.white70)),
            )
          ],
        ),
      ),
    );
  }

  Widget _drawerMenuItem(IconData icon, String label, VoidCallback onTap) {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, value, child) {
        return Opacity(opacity: value, child: child);
      },
      child: ListTile(
        leading: Icon(icon, color: Colors.white),
        title: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
        onTap: onTap,
      ),
    );
  }

  Route _fadeRoute(Widget screen) {
    return PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 600),
      pageBuilder: (_, __, ___) => screen,
      transitionsBuilder: (_, animation, __, child) {
        return FadeTransition(opacity: animation, child: child);
      },
    );
  }
}
