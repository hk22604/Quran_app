import 'package:flutter/material.dart';

class NamesOfAllahScreen extends StatefulWidget {
  @override
  _NamesOfAllahScreenState createState() => _NamesOfAllahScreenState();
}

class _NamesOfAllahScreenState extends State<NamesOfAllahScreen> {
  List<Map<String, String>> allNames = [];
  List<Map<String, String>> displayedNames = [];
  Set<int> favoriteIndices = Set();
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    allNames = namesOfAllah;
    displayedNames = List.from(allNames);
  }

  void filterSearch(String query) {
    final results = allNames.where((name) {
      final title = name['name']!;
      final meaning = name['meaning']!;
      return title.contains(query) || meaning.toLowerCase().contains(query.toLowerCase());
    }).toList();

    setState(() {
      displayedNames = results;
    });
  }

  @override
  Widget build(BuildContext context) {
    final gradient = const LinearGradient(
      colors: [Color(0xFFa8e063), Color(0xFF56ab2f)],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text("99 Names of Allah"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: gradient)),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: searchController,
              onChanged: filterSearch,
              decoration: InputDecoration(
                hintText: "Search names or meanings...",
                prefixIcon: Icon(Icons.search),
                filled: true,
                fillColor: Colors.green[50],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: displayedNames.length,
              itemBuilder: (context, index) {
                final name = displayedNames[index];
                final actualIndex = allNames.indexOf(name);
                final isFav = favoriteIndices.contains(actualIndex);

                return TweenAnimationBuilder(
                  duration: Duration(milliseconds: 400 + (index * 50)),
                  tween: Tween<double>(begin: 0, end: 1),
                  builder: (context, value, child) => Opacity(
                    opacity: value,
                    child: Transform.translate(
                      offset: Offset(0, 30 * (1 - value)),
                      child: child,
                    ),
                  ),
                  child: Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.green,
                        child: Text(
                          "${actualIndex + 1}",
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                      title: Text(name['name']!,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      subtitle: Text(name['meaning']!,
                          style: TextStyle(color: Colors.grey[700])),
                      trailing: IconButton(
                        icon: Icon(
                          isFav ? Icons.favorite : Icons.favorite_border,
                          color: isFav ? Colors.red : Colors.grey,
                        ),
                        onPressed: () {
                          setState(() {
                            if (isFav) {
                              favoriteIndices.remove(actualIndex);
                            } else {
                              favoriteIndices.add(actualIndex);
                            }
                          });
                        },
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ✅ Full 99 Names of Allah
final List<Map<String, String>> namesOfAllah = [
  {"name": "الرَّحْمَنُ", "meaning": "The Beneficent"},
  {"name": "الرَّحِيمُ", "meaning": "The Merciful"},
  {"name": "الْمَلِكُ", "meaning": "The King and Owner of Dominion"},
  {"name": "الْقُدُّوسُ", "meaning": "The Absolutely Pure"},
  {"name": "السَّلَامُ", "meaning": "The Source of Peace, Safety"},
  {"name": "الْمُؤْمِنُ", "meaning": "The One Who gives Emaan and Security"},
  {"name": "الْمُهَيْمِنُ", "meaning": "The Guardian, The Witness, The Overseer"},
  {"name": "الْعَزِيزُ", "meaning": "The Almighty"},
  {"name": "الْجَبَّارُ", "meaning": "The Compeller, The Restorer"},
  {"name": "الْمُتَكَبِّر", "meaning": "The Supreme, The Majestic"},
  {"name": "الْخَالِقُ", "meaning": "The Creator, The Maker"},
  {"name": "الْبَارِئُ", "meaning": "The Evolver"},
  {"name": "الْمُصَوِّرُ", "meaning": "The Fashioner"},
  {"name": "الْغَفَّارُ", "meaning": "The Constant Forgiver"},
  {"name": "الْقَهَّارُ", "meaning": "The All-Subduer"},
  {"name": "الْوَهَّابُ", "meaning": "The Supreme Bestower"},
  {"name": "الرَّزَّاقُ", "meaning": "The Provider"},
  {"name": "الْفَتَّاحُ", "meaning": "The Supreme Opener"},
  {"name": "اَلْعَلِيْمُ", "meaning": "The All-Knowing"},
  {"name": "الْقَابِضُ", "meaning": "The Withholder"},
  {"name": "الْبَاسِطُ", "meaning": "The Extender"},
  {"name": "الْخَافِضُ", "meaning": "The Reducer"},
  {"name": "الرَّافِعُ", "meaning": "The Exalter, the Elevator"},
  {"name": "الْمُعِزُّ", "meaning": "The Honourer, the Bestower"},
  {"name": "المُذِلُّ", "meaning": "The Dishonourer"},
  {"name": "السَّمِيعُ", "meaning": "The All-Hearing"},
  {"name": "الْبَصِيرُ", "meaning": "The All-Seeing"},
  {"name": "الْحَكَمُ", "meaning": "The Impartial Judge"},
  {"name": "الْعَدْلُ", "meaning": "The Utterly Just"},
  {"name": "اللَّطِيفُ", "meaning": "The Subtle One, the Most Gentle"},
  {"name": "الْخَبِيرُ", "meaning": "The All-Aware"},
  {"name": "الْحَلِيمُ", "meaning": "The Most Forbearing"},
  {"name": "الْعَظِيمُ", "meaning": "The Magnificent, the Infinite"},
  {"name": "الْغَفُور", "meaning": "The Great Forgiver"},
  {"name": "الشَّكُورُ", "meaning": "The Most Appreciative"},
  {"name": "الْعَلِيُّ", "meaning": "The Most High, the Exalted"},
  {"name": "الْكَبِيرُ", "meaning": "The Most Great"},
  {"name": "الْحَفِيظُ", "meaning": "The Preserver"},
  {"name": "المُقيِت", "meaning": "The Sustainer"},
  {"name": "اﻟْﺣَسِيبُ", "meaning": "The Reckoner"},
  {"name": "الْجَلِيلُ", "meaning": "The Majestic"},
  {"name": "الْكَرِيمُ", "meaning": "The Most Generous, the Most Esteemed"},
  {"name": "الرَّقِيبُ", "meaning": "The Watchful"},
  {"name": "الْمُجِيبُ", "meaning": "The Responsive One"},
  {"name": "الْوَاسِعُ", "meaning": "The All-Encompassing, the Boundless"},
  {"name": "الْحَكِيمُ", "meaning": "The All-Wise"},
  {"name": "الْوَدُودُ", "meaning": "The Most Loving"},
  {"name": "الْمَجِيدُ", "meaning": "The Glorious, the Most Honorable"},
  {"name": "الْبَاعِثُ", "meaning": "The Infuser of New Life"},
  {"name": "الشَّهِيدُ", "meaning": "The All-and-Ever Witnessing"},
  {"name": "الْحَقُ", "meaning": "The Absolute Truth"},
  {"name": "الْوَكِيلُ", "meaning": "The Trustee, the Disposer of Affairs"},
  {"name": "الْقَوِيُ", "meaning": "The All-Strong"},
  {"name": "الْمَتِينُ", "meaning": "The Firm One"},
  {"name": "الْوَلِيُ", "meaning": "The Sole Provider"},
  {"name": "الْحَمِيدُ", "meaning": "The Praiseworthy"},
  {"name": "الْمُحْصِي", "meaning": "The All-Enumerating, the Counter"},
  {"name": "الْمُبْدِئُ", "meaning": "The Originator, the Initiator"},
  {"name": "الْمُعِيدُ", "meaning": "The Restorer, the Reinstater"},
  {"name": "الْمُحْيِي", "meaning": "The Giver of Life"},
  {"name": "المُمِيت", "meaning": "The Creator of Death"},
  {"name": "الْحَيُّ", "meaning": "The Ever-Living"},
  {"name": "الْقَيُّومُ", "meaning": "The Sustainer, The Self-Subsisting"},
  {"name": "الْوَاجِدُ", "meaning": "The Perceiver"},
  {"name": "الْمَاجِدُ", "meaning": "The Glorious, the Most Honorable"},
  {"name": "الواحِدُ", "meaning": "The Indivisible, the Absolute, the One"},
  {"name": "اَلاَحَد", "meaning": "The Infinite, the Eternal"},
  {"name": "الصَّمَدُ", "meaning": "The Self-Sufficient, the Impregnable"},
  {"name": "الْقَادِرُ", "meaning": "The Omnipotent"},
  {"name": "الْمُقْتَدِرُ", "meaning": "The Creator of All Power"},
  {"name": "الْمُقَدِّمُ", "meaning": "The Expediter"},
  {"name": "الْمُؤَخِّرُ", "meaning": "The Delayer"},
  {"name": "الأوَّلُ", "meaning": "The First"},
  {"name": "الآخِرُ", "meaning": "The Last"},
  {"name": "الظَّاهِرُ", "meaning": "The Manifest"},
  {"name": "الْبَاطِنُ", "meaning": "The Hidden One, Knower of the Hidden"},
  {"name": "الْوَالِي", "meaning": "The Sole Governor"},
  {"name": "الْمُتَعَالِي", "meaning": "The Self Exalted"},
  {"name": "الْبَرُّ", "meaning": "The Source of All Goodness"},
  {"name": "التَّوَابُ", "meaning": "The Ever-Accepter of Repentance"},
  {"name": "الْمُنْتَقِمُ", "meaning": "The Avenger"},
  {"name": "العَفُوُ", "meaning": "The Supreme Pardoner"},
  {"name": "الرَّؤُوفُ", "meaning": "The Most Kind"},
  {"name": "مَالِكُ الْمُلْكِ", "meaning": "Master and King of the Kingdom"},
  {"name": "ذُوالْجَلاَلِ وَالإكْرَامِ", "meaning": "Lord of Glory and Honour"},
  {"name": "الْمُقْسِطُ", "meaning": "The Just One"},
  {"name": "الْجَامِعُ", "meaning": "The Gatherer, the Uniter"},
  {"name": "ٱلْغَنيُ", "meaning": "The Self-Sufficient"},
  {"name": "ٱلْمُغْنِيُ", "meaning": "The Enricher"},
  {"name": "اَلْمَانِعُ", "meaning": "The Withholder"},
  {"name": "الضَّارَ", "meaning": "Distresser"},
  {"name": "النَّافِعُ", "meaning": "The Benefactor"},
  {"name": "النُّورُ", "meaning": "The Light"},
  {"name": "الْهَادِي", "meaning": "The Guide"},
  {"name": "الْبَدِيعُ", "meaning": "The Incomparable Originator"},
  {"name": "البَاقِي", "meaning": "The Everlasting"},
  {"name": "الْوَارِثُ", "meaning": "The Inheritor"},
  {"name": "الرَّشِيدُ", "meaning": "The Infallible Teacher"},
  {"name": "الصَّبُورُ", "meaning": "The Most Patient"},
];
