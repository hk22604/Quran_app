import 'dart:async';
import 'package:flutter/material.dart';
import 'package:location/location.dart' as loc;
import 'package:geocoding/geocoding.dart';
import 'package:adhan/adhan.dart';
import 'package:intl/intl.dart';
import 'package:hijri/hijri_calendar.dart';

class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({super.key});

  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  final Color primaryBlue = Color(0xFF006D77);
  final Color bg = Color(0xFFF0F9FF);
  final Color highlight = Color(0xFF4CAF50);

  Map<String, DateTime> prayerTimes = {};
  String status = "Loading…";
  String locationName = "Locating…";
  String nextPrayer = "";
  Duration timeLeft = Duration.zero;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final locServ = loc.Location();

      if (!await locServ.serviceEnabled() && !await locServ.requestService()) {
        setState(() => status = 'Please enable location services');
        return;
      }

      if (await locServ.hasPermission() == loc.PermissionStatus.denied &&
          await locServ.requestPermission() != loc.PermissionStatus.granted) {
        setState(() => status = 'Allow location access');
        return;
      }

      final ld = await locServ.getLocation();
      final pl = await placemarkFromCoordinates(ld.latitude!, ld.longitude!);
      if (pl.isNotEmpty) {
        final p = pl.first;
        locationName = "${p.locality ?? p.subAdministrativeArea}, ${p.country}";
      }

      final coords = Coordinates(ld.latitude!, ld.longitude!);
      final params = CalculationMethod.karachi.getParameters()..madhab = Madhab.hanafi;
      final pt = PrayerTimes.today(coords, params);

      setState(() {
        prayerTimes = {
          'Fajr': pt.fajr,
          'Sunrise': pt.sunrise,
          'Dhuhr': pt.dhuhr,
          'Asr': pt.asr,
          'Maghrib': pt.maghrib,
          'Isha': pt.isha,
        };
        status = "";
      });

      _updateNext();
    } catch (e) {
      setState(() => status = "Error: ${e.toString()}");
    }
  }

  void _updateNext() {
    for (var entry in prayerTimes.entries) {
      if (entry.value.isAfter(DateTime.now())) {
        nextPrayer = entry.key;
        timeLeft = entry.value.difference(DateTime.now());
        timer?.cancel();
        timer = Timer.periodic(Duration(seconds: 1), (_) {
          setState(() {
            timeLeft = entry.value.difference(DateTime.now());
            if (timeLeft.inSeconds <= 0) _updateNext();
          });
        });
        break;
      }
    }
  }

  String _fmtTime(DateTime dt) {
    final h = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final m = dt.minute.toString().padLeft(2, '0');
    final ap = dt.hour >= 12 ? 'PM' : 'AM';
    return "$h:$m $ap";
  }

  String _fmtCountdown(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    return "${h}h ${m}m ${s}s";
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hijri = HijriCalendar.now();
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: primaryBlue,
        elevation: 0,
        title: Text('Prayer Times', style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: status.isNotEmpty ? _buildStatus() : _buildBody(hijri),
    );
  }

  Widget _buildStatus() => Center(
    child: Text(status, style: TextStyle(color: primaryBlue, fontSize: 16)),
  );

  Widget _buildBody(HijriCalendar hijri) => SafeArea(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("📍 $locationName",
                  style:
                  TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              SizedBox(height: 4),
              Text(
                "${DateFormat('EEE, d MMM yyyy').format(DateTime.now())} / ${hijri.toFormat('dd MMMM yyyy')}",
                style: TextStyle(color: Colors.grey[700], fontSize: 14),
              ),
              SizedBox(height: 8),
              if (nextPrayer.isNotEmpty)
                Container(
                  padding:
                  EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                  decoration: BoxDecoration(
                    color: highlight.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    "$nextPrayer starts in ${_fmtCountdown(timeLeft)}",
                    style: TextStyle(
                        color: highlight,
                        fontSize: 16,
                        fontWeight: FontWeight.bold),
                  ),
                ),
            ],
          ),
        ),
        Expanded(child: _buildPrayerList()),
      ],
    ),
  );

  Widget _buildPrayerList() => ListView.separated(
    padding: EdgeInsets.symmetric(horizontal: 20),
    itemCount: prayerTimes.length,
    separatorBuilder: (_, __) => SizedBox(height: 12),
    itemBuilder: (_, i) {
      final entry = prayerTimes.entries.elementAt(i);
      final isNext = entry.key == nextPrayer;
      return Card(
        color: isNext ? highlight.withOpacity(0.1) : Colors.white,
        shape:
        RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: isNext ? 4 : 1,
        child: ListTile(
          contentPadding:
          EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: Icon(Icons.access_time,
              color: isNext ? highlight : primaryBlue),
          title: Text(entry.key,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: isNext ? highlight : Colors.black)),
          trailing: Text(_fmtTime(entry.value),
              style: TextStyle(color: Colors.grey[800], fontSize: 16)),
        ),
      );
    },
  );
}
