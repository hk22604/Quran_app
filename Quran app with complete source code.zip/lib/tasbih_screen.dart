import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:confetti/confetti.dart';
import 'package:table_calendar/table_calendar.dart';
import 'dart:convert';
import 'package:fl_chart/fl_chart.dart';
import 'package:lottie/lottie.dart';

class TasbihScreen extends StatefulWidget {
  @override
  _TasbihScreenState createState() => _TasbihScreenState();
}

class _TasbihScreenState extends State<TasbihScreen> with TickerProviderStateMixin {
  final List<String> waazifahs = [
    "اَسْتَغْفِرُاللّٰهَ", "اَللّٰهُ اَكْبَرُ", "سُبْحَانَ اللّٰهِ", "الْـحَمْـدُ للهِ",
    "سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ", "سُبْحَانَ اللّٰهِ الْعَظِيمِ", "لَا اِلٰہَ اِلَّا اللّٰهُ",
    "اَللّٰهُمَّ صَلِّ عَلٰی مُحَمَّدٍ وَّ عَلٰی آلِ مُحَمَّدٍ"
  ];

  final List<int> goalOptions = [7, 10, 33, 41, 100, 500, 1000];
  final String topArabicDua = "وَاذْكُرْ رَبَّكَ كَثِيرًا وَسَبِّحْ بِالْعَشِيِّ وَالْإِبْكَارِ";
  final String topTranslation = "اور اپنے رب کا ذکر کثرت سے کیا کرو اور صبح و شام تسبیح کیا کرو۔";

  int _currentWaazifahIndex = 0;
  int _count = 0;
  int _goal = 33;
  Set<String> completedDates = {};
  Map<String, List<String>> dailyProgress = {};

  late ConfettiController _confettiController;
  late PageController _pageController;

  late AnimationController _countAnimationController;
  late Animation<double> _countScaleAnimation;

  String get todayKey => DateTime.now().toIso8601String().substring(0, 10);
  String get selectedWaazifah => waazifahs[_currentWaazifahIndex];
  String get _countKey => 'count_${selectedWaazifah.hashCode}';

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: Duration(seconds: 2));
    _pageController = PageController(viewportFraction: 0.85, initialPage: _currentWaazifahIndex);

    _countAnimationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 200),
    );
    _countScaleAnimation = Tween<double>(begin: 1.0, end: 1.3)
        .chain(CurveTween(curve: Curves.easeOut))
        .animate(_countAnimationController);

    _loadData();
  }

  @override
  void dispose() {
    _confettiController.dispose();
    _pageController.dispose();
    _countAnimationController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    _count = prefs.getInt(_countKey) ?? 0;
    _goal = prefs.getInt('goal') ?? 33;
    completedDates = (prefs.getStringList('completedDates') ?? []).toSet();
    final jsonString = prefs.getString('dailyProgress') ?? '{}';
    dailyProgress = Map<String, List<String>>.from(
      json.decode(jsonString).map((key, value) => MapEntry(key, List<String>.from(value))),
    );
    setState(() {});
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt(_countKey, _count);
    prefs.setInt('goal', _goal);
    prefs.setStringList('completedDates', completedDates.toList());
    prefs.setString('dailyProgress', json.encode(dailyProgress));
  }

  Future<void> _resetCounter() async {
    _count = 0;
    await _saveData();
    setState(() {});
  }

  Future<void> _incrementCounter() async {
    _count++;
    _countAnimationController.forward(from: 0.0);

    if (_count >= _goal) {
      _confettiController.play();
      _count = 0;
      completedDates.add(todayKey);
      dailyProgress[todayKey] = [...?dailyProgress[todayKey], selectedWaazifah];
    }

    await _saveData();
    setState(() {});
  }

  Widget _buildWaazifahCard(String text, bool isSelected) {
    bool isCompletedToday = dailyProgress[todayKey]?.contains(text) ?? false;

    return Stack(
      children: [
        AnimatedContainer(
          duration: Duration(milliseconds: 300),
          margin: EdgeInsets.symmetric(horizontal: 6, vertical: isSelected ? 0 : 12),
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isSelected ? Colors.green[100] : Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.teal, width: isSelected ? 2 : 1),
            boxShadow: [
              BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
            ],
          ),
          child: Center(
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal[800]),
            ),
          ),
        ),
        if (isCompletedToday)
          Positioned(
            top: 8,
            right: 8,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 22),
                SizedBox(width: 6),
                GestureDetector(
                  onTap: () => _showWazifahDetailReport(text),
                  child: Icon(Icons.bar_chart, color: Colors.teal[800], size: 22),
                ),
              ],
            ),
          ),
      ],
    );
  }

  void _showWazifahDetailReport(String wazifah) {
    final now = DateTime.now();
    int dailyCount = dailyProgress[todayKey]?.where((w) => w == wazifah).length ?? 0;

    int weeklyCount = 0;
    for (int i = 0; i < 7; i++) {
      final key = now.subtract(Duration(days: i)).toIso8601String().substring(0, 10);
      weeklyCount += dailyProgress[key]?.where((w) => w == wazifah).length ?? 0;
    }

    int monthlyCount = 0;
    for (int i = 0; i < 30; i++) {
      final key = now.subtract(Duration(days: i)).toIso8601String().substring(0, 10);
      monthlyCount += dailyProgress[key]?.where((w) => w == wazifah).length ?? 0;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("📊 $wazifah Report", style: TextStyle(color: Colors.teal[800])),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("📅 Today: $dailyCount times"),
            Text("🗓️ Last 7 days: $weeklyCount times"),
            Text("📆 Last 30 days: $monthlyCount times"),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Close", style: TextStyle(color: Colors.teal)),
          )
        ],
      ),
    );
  }

  void _openReportScreen() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (context) {
        final width = MediaQuery.of(context).size.width;
        final height = MediaQuery.of(context).size.height;

        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.95,
          builder: (_, controller) => SingleChildScrollView(
            controller: controller,
            child: Column(
              children: [
                SizedBox(height: height * 0.02),
                Text("Tasbih Calendar", style: TextStyle(fontSize: width * 0.05, fontWeight: FontWeight.bold, color: Colors.teal[900])),
                Padding(
                  padding: EdgeInsets.all(width * 0.03),
                  child: TableCalendar(
                    focusedDay: DateTime.now(),
                    firstDay: DateTime.utc(2020, 1, 1),
                    lastDay: DateTime.utc(2030, 12, 31),
                    calendarFormat: CalendarFormat.month,
                    startingDayOfWeek: StartingDayOfWeek.sunday,
                    headerStyle: HeaderStyle(
                      formatButtonVisible: false,
                      titleCentered: true,
                      titleTextStyle: TextStyle(fontSize: width * 0.045, fontWeight: FontWeight.bold, color: Colors.teal[900]),
                      leftChevronIcon: Icon(Icons.arrow_back_ios, color: Colors.teal),
                      rightChevronIcon: Icon(Icons.arrow_forward_ios, color: Colors.teal),
                    ),
                    calendarStyle: CalendarStyle(
                      todayDecoration: BoxDecoration(color: Colors.teal, shape: BoxShape.circle),
                      selectedDecoration: BoxDecoration(color: Colors.teal[900], shape: BoxShape.circle),
                      defaultTextStyle: TextStyle(color: Colors.black),
                      todayTextStyle: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      outsideTextStyle: TextStyle(color: Colors.grey[400]),
                      weekendTextStyle: TextStyle(color: Colors.teal[700]),
                      markerDecoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle),
                    ),
                    calendarBuilders: CalendarBuilders(
                      defaultBuilder: (context, day, _) {
                        final isCompleted = completedDates.contains(day.toIso8601String().substring(0, 10));
                        return Center(
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Text('${day.day}', style: TextStyle(color: Colors.black)),
                              if (isCompleted)
                                Positioned(
                                  bottom: 4,
                                  child: Container(
                                    width: 6,
                                    height: 6,
                                    decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle),
                                  ),
                                ),
                            ],
                          ),
                        );
                      },
                      todayBuilder: (context, day, _) {
                        final isCompleted = completedDates.contains(day.toIso8601String().substring(0, 10));
                        return Center(
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(color: Colors.teal, shape: BoxShape.circle),
                                child: Text('${day.day}', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                              ),
                              if (isCompleted)
                                Positioned(
                                  bottom: 4,
                                  child: Container(
                                    width: 6,
                                    height: 6,
                                    decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle),
                                  ),
                                ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(width * 0.04),
                  child: Text("Last 7 Days Progress", style: TextStyle(fontSize: width * 0.045, fontWeight: FontWeight.bold, color: Colors.teal[800])),
                ),
                SizedBox(
                  height: height * 0.3,
                  child: BarChart(
                    BarChartData(
                      borderData: FlBorderData(show: false),
                      titlesData: FlTitlesData(show: true),
                      barGroups: List.generate(7, (index) {
                        final day = DateTime.now().subtract(Duration(days: 6 - index));
                        final key = day.toIso8601String().substring(0, 10);
                        final value = dailyProgress[key]?.length ?? 0;
                        return BarChartGroupData(
                          x: index,
                          barRods: [
                            BarChartRodData(toY: value.toDouble(), color: Colors.teal, width: 16),
                          ],
                        );
                      }),
                    ),
                  ),
                ),
                SizedBox(height: height * 0.03),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final width = size.width;
    final height = size.height;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("Tasbih Counter", style: TextStyle(fontSize: width * 0.05)),
        backgroundColor: Colors.teal,
        elevation: 0,
        actions: [
          IconButton(icon: Icon(Icons.bar_chart, size: width * 0.07), onPressed: _openReportScreen),
        ],
      ),
      body: Stack(
        children: [
          Positioned.fill(child: Lottie.asset('assets/bg.json', fit: BoxFit.cover)),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  physics: BouncingScrollPhysics(),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: constraints.maxHeight),
                    child: IntrinsicHeight(
                      child: Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.all(width * 0.04),
                            child: Column(
                              children: [
                                Text(topArabicDua, style: TextStyle(fontSize: width * 0.045, color: Colors.teal[900], fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                                SizedBox(height: height * 0.01),
                                Text(topTranslation, style: TextStyle(fontSize: width * 0.035, color: Colors.teal[800]), textAlign: TextAlign.center),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: height * 0.16,
                            child: PageView.builder(
                              controller: _pageController,
                              itemCount: waazifahs.length,
                              scrollDirection: Axis.horizontal,
                              onPageChanged: (index) => setState(() {
                                _currentWaazifahIndex = index;
                                _loadData();
                              }),
                              itemBuilder: (context, index) => _buildWaazifahCard(waazifahs[index], index == _currentWaazifahIndex),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: width * 0.08, vertical: height * 0.015),
                            child: DropdownButton<int>(
                              value: _goal,
                              isExpanded: true,
                              iconEnabledColor: Colors.teal,
                              items: goalOptions.map((e) => DropdownMenuItem(value: e, child: Text("Goal: $e times"))).toList(),
                              onChanged: (val) => setState(() => _goal = val ?? _goal),
                            ),
                          ),
                          ScaleTransition(
                            scale: _countScaleAnimation,
                            child: Text(
                              '$_count',
                              style: TextStyle(fontSize: width * 0.15, fontWeight: FontWeight.bold, color: Colors.black),
                            ),
                          ),
                          ElevatedButton(
                            onPressed: _incrementCounter,
                            child: Text("Tap to Count", style: TextStyle(fontSize: width * 0.045)),
                            style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.symmetric(horizontal: width * 0.15, vertical: height * 0.02),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                              backgroundColor: Colors.teal,
                            ),
                          ),
                          TextButton(
                            onPressed: _resetCounter,
                            child: Text("Reset", style: TextStyle(fontSize: width * 0.04, color: Colors.teal[800])),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          ConfettiWidget(
            confettiController: _confettiController,
            blastDirectionality: BlastDirectionality.explosive,
            shouldLoop: false,
            gravity: 0.3,
          ),
        ],
      ),
    );
  }
}
