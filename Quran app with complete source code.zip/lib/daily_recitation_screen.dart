import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class SurahAudioPlayerScreen extends StatefulWidget {
  final String surahName;
  final List<String> audioUrls;

  SurahAudioPlayerScreen({
    required this.surahName,
    required this.audioUrls,
  });

  @override
  _SurahAudioPlayerScreenState createState() => _SurahAudioPlayerScreenState();
}

class _SurahAudioPlayerScreenState extends State<SurahAudioPlayerScreen> {
  late AudioPlayer player;
  int currentIndex = 0;

  @override
  void initState() {
    super.initState();
    player = AudioPlayer();
    playAudio();
    player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed &&
          currentIndex < widget.audioUrls.length - 1) {
        currentIndex++;
        playAudio();
      }
    });
  }

  void playAudio() async {
    try {
      await player.setUrl(widget.audioUrls[currentIndex]);
      player.play();
    } catch (e) {
      print("Audio error: $e");
    }
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = Color(0xFF006D77);
    return Scaffold(
      appBar: AppBar(
        title: Text("Playing ${widget.surahName}"),
        backgroundColor: themeColor,
      ),
      body: Container(
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [themeColor.withOpacity(0.8), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.library_music, size: 80, color: themeColor),
              SizedBox(height: 30),
              Text(
                "Now Playing:",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              Text(
                "${widget.surahName} - Ayah ${currentIndex + 1}",
                style: TextStyle(fontSize: 20, color: Colors.grey[700]),
              ),
              SizedBox(height: 40),
              StreamBuilder<PlayerState>(
                stream: player.playerStateStream,
                builder: (context, snapshot) {
                  final state = snapshot.data;
                  final playing = state?.playing ?? false;
                  return IconButton(
                    iconSize: 64,
                    icon: Icon(
                      playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                      color: themeColor,
                    ),
                    onPressed: () {
                      if (playing) {
                        player.pause();
                      } else {
                        player.play();
                      }
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
