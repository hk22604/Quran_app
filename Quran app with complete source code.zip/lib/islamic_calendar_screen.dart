import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';

class IslamicCalendarScreen extends StatefulWidget {
  @override
  _IslamicCalendarScreenState createState() => _IslamicCalendarScreenState();
}

class _IslamicCalendarScreenState extends State<IslamicCalendarScreen> {
  late HijriCalendar today;
  late int totalDays;
  late List<HijriCalendar> monthDays;

  final Color darkGreen = const Color(0xFF2E7D32); // Primary dark green
  final Color lightGreen = const Color(0xFFA5D6A7); // Light green shade

  @override
  void initState() {
    super.initState();
    HijriCalendar.setLocal("en");

    today = HijriCalendar.now();

    HijriCalendar temp = HijriCalendar()
      ..hYear = today.hYear
      ..hMonth = today.hMonth;

    totalDays = temp.getDaysInMonth(temp.hYear, temp.hMonth);

    monthDays = List.generate(totalDays, (i) {
      return HijriCalendar()
        ..hYear = today.hYear
        ..hMonth = today.hMonth
        ..hDay = i + 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Islamic Calendar"),
        backgroundColor: darkGreen,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [darkGreen.withOpacity(0.95), lightGreen.withOpacity(0.6)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 20),
            Text(
              "${today.longMonthName} ${today.hYear} AH",
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const Divider(color: Colors.white70),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: _buildWeekDaysHeader(),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(12),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemCount: monthDays.length,
                itemBuilder: (context, index) {
                  final day = monthDays[index];
                  bool isToday = (day.hDay == today.hDay &&
                      day.hMonth == today.hMonth &&
                      day.hYear == today.hYear);

                  return Container(
                    decoration: BoxDecoration(
                      color: isToday ? Colors.white : Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white70),
                    ),
                    child: Center(
                      child: Text(
                        '${day.hDay}',
                        style: TextStyle(
                          color: isToday ? darkGreen : Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeekDaysHeader() {
    final days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: days
          .map((day) => Expanded(
        child: Center(
          child: Text(
            day,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ))
          .toList(),
    );
  }
}
