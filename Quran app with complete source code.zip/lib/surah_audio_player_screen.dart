import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class SurahAudioPlayerScreen extends StatefulWidget {
  final String surahName;
  final List<String> audioUrls;

  SurahAudioPlayerScreen({
    required this.surahName,
    required this.audioUrls,
  });

  @override
  _SurahAudioPlayerScreenState createState() => _SurahAudioPlayerScreenState();
}

class _SurahAudioPlayerScreenState extends State<SurahAudioPlayerScreen> {
  late AudioPlayer _audioPlayer;
  int _currentIndex = 0;
  bool _isPlaying = false;

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();
    _playCurrentAyah();
  }

  Future<void> _playCurrentAyah() async {
    try {
      await _audioPlayer.setUrl(widget.audioUrls[_currentIndex]);
      _audioPlayer.play();
      setState(() => _isPlaying = true);

      _audioPlayer.playerStateStream.listen((state) {
        if (state.processingState == ProcessingState.completed) {
          if (_currentIndex < widget.audioUrls.length - 1) {
            setState(() => _currentIndex++);
            _playCurrentAyah();
          } else {
            setState(() => _isPlaying = false);
          }
        }
      });
    } catch (e) {
      setState(() => _isPlaying = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to load ayah.")),
      );
    }
  }

  void _playNextAyah() {
    if (_currentIndex < widget.audioUrls.length - 1) {
      setState(() => _currentIndex++);
      _playCurrentAyah();
    }
  }

  void _playPreviousAyah() {
    if (_currentIndex > 0) {
      setState(() => _currentIndex--);
      _playCurrentAyah();
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.audioUrls.length;
    final current = _currentIndex + 1;
    final progress = current / total;

    return Scaffold(
      backgroundColor: Color(0xFF121826),
      appBar: AppBar(
        title: Text(widget.surahName),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
        child: Column(
          children: [
            Spacer(),
            Text(
              'Playing Ayah $current of $total',
              style: TextStyle(
                fontSize: 20,
                color: Colors.tealAccent,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 20),
            Container(
              height: 180,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  colors: [Colors.teal.shade600, Colors.teal.shade200],
                ),
              ),
              alignment: Alignment.center,
              child: Icon(
                Icons.graphic_eq,
                size: 100,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 30),
            LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              backgroundColor: Colors.white12,
              valueColor:
              AlwaysStoppedAnimation<Color>(Colors.tealAccent.shade700),
            ),
            SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Previous Button
                IconButton(
                  iconSize: 40,
                  color: Colors.tealAccent,
                  icon: Icon(Icons.skip_previous),
                  onPressed: _currentIndex > 0 ? _playPreviousAyah : null,
                ),
                SizedBox(width: 20),
                // Play/Pause Button
                GestureDetector(
                  onTap: () {
                    if (_isPlaying) {
                      _audioPlayer.pause();
                      setState(() => _isPlaying = false);
                    } else {
                      _audioPlayer.play();
                      setState(() => _isPlaying = true);
                    }
                  },
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [Colors.tealAccent, Colors.teal],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.tealAccent.withOpacity(0.4),
                          blurRadius: 20,
                          spreadRadius: 5,
                        )
                      ],
                    ),
                    child: Icon(
                      _isPlaying ? Icons.pause : Icons.play_arrow,
                      size: 40,
                      color: Colors.black,
                    ),
                  ),
                ),
                SizedBox(width: 20),
                // Next Button
                IconButton(
                  iconSize: 40,
                  color: Colors.tealAccent,
                  icon: Icon(Icons.skip_next),
                  onPressed: _currentIndex < total - 1 ? _playNextAyah : null,
                ),
              ],
            ),
            Spacer(),
          ],
        ),
      ),
    );
  }
}
