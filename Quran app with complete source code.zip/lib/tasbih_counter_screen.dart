import 'package:flutter/material.dart';

class TasbihCounterScreen extends StatefulWidget {
  @override
  _TasbihCounterScreenState createState() => _TasbihCounterScreenState();
}

class _TasbihCounterScreenState extends State<TasbihCounterScreen> {
  int _count = 0;

  void _incrementCounter() {
    setState(() {
      _count++;
    });
  }

  void _resetCounter() {
    setState(() {
      _count = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFE8F6F3),
      appBar: AppBar(
        title: Text(
          'Tasbih Counter',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Color(0xFF006D77),
        elevation: 4,
      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 12,
                offset: Offset(0, 6),
              )
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Count',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF006D77),
                ),
              ),
              SizedBox(height: 10),
              Text(
                '$_count',
                style: TextStyle(
                  fontSize: 60,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: _incrementCounter,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF006D77),
                      shape: CircleBorder(),
                      padding: EdgeInsets.all(24),
                      elevation: 6,
                    ),
                    child: Icon(Icons.add, size: 30, color: Colors.white),
                  ),
                  SizedBox(width: 30),
                  ElevatedButton(
                    onPressed: _resetCounter,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF83C5BE),
                      shape: CircleBorder(),
                      padding: EdgeInsets.all(24),
                      elevation: 6,
                    ),
                    child: Icon(Icons.refresh, size: 28, color: Colors.white),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
