import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'surah_detail_screen.dart';

class DownloadedSurahsScreen extends StatefulWidget {
  @override
  _DownloadedSurahsScreenState createState() => _DownloadedSurahsScreenState();
}

class _DownloadedSurahsScreenState extends State<DownloadedSurahsScreen> {
  Map<int, List<int>> downloadedSurahs = {}; // {surah: [ayah numbers]}
  Map<int, double> surahSizes = {};          // {surah: size in MB}
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadDownloadedSurahs();
  }

  Future<void> _loadDownloadedSurahs() async {
    final prefs = await SharedPreferences.getInstance();
    final keys = (prefs.getStringList('downloaded_ayahs') ?? []);
    final dir = await getApplicationDocumentsDirectory();

    Map<int, List<int>> grouped = {};
    Map<int, double> sizes = {};

    for (var key in keys) {
      final parts = key.split(':');
      if (parts.length != 2) continue;
      final s = int.tryParse(parts[0]);
      final a = int.tryParse(parts[1]);
      if (s == null || a == null) continue;

      grouped.putIfAbsent(s, () => []).add(a);

      final file = File('${dir.path}/surah_${s}_ayah_${a}.mp3');
      if (await file.exists()) {
        sizes[s] = (sizes[s] ?? 0) + file.lengthSync() / (1024 * 1024);
      }
    }

    setState(() {
      downloadedSurahs = grouped;
      surahSizes = sizes;
      isLoading = false;
    });
  }

  Future<void> _deleteSurah(int s) async {
    final prefs = await SharedPreferences.getInstance();
    final dir = await getApplicationDocumentsDirectory();

    for (int a in downloadedSurahs[s]!) {
      final file = File('${dir.path}/surah_${s}_ayah_${a}.mp3');
      if (await file.exists()) await file.delete();
      prefs.getStringList('downloaded_ayahs')?.remove('$s:$a');
    }

    await prefs.setStringList('downloaded_ayahs', prefs.getStringList('downloaded_ayahs') ?? []);

    setState(() {
      downloadedSurahs.remove(s);
      surahSizes.remove(s);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Deleted Surah $s')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final primaryGreen = Color(0xFF2E7D32);

    if (isLoading) {
      return Scaffold(
        appBar: AppBar(title: Text('Downloaded Surahs'), backgroundColor: primaryGreen),
        body: Center(child: CircularProgressIndicator(color: primaryGreen)),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text('Downloaded Surahs'), backgroundColor: primaryGreen),
      body: downloadedSurahs.isEmpty
          ? Center(child: Text("No surahs downloaded."))
          : ListView(
        children: downloadedSurahs.keys.map((s) {
          final ayahList = downloadedSurahs[s]!..sort();
          final sizeMb = surahSizes[s] ?? 0.0;

          return Card(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              title: Text('Surah $s'),
              subtitle: Text('${ayahList.length} ayah(s) • ${sizeMb.toStringAsFixed(1)} MB'),
              trailing: PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'open') {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (_) => SurahDetailScreen(
                        surahNumber: s,
                        surahName: 'Surah $s',
                        initialAyah: ayahList.first,
                      ),
                    ));
                  } else if (v == 'delete') {
                    _deleteSurah(s);
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(child: Text('Open'), value: 'open'),
                  PopupMenuItem(child: Text('Delete'), value: 'delete'),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
