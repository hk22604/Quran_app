import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:islamic_app/screens/IntroSplashScreen.dart';
import 'package:islamic_app/login_screen.dart';
import 'package:islamic_app/signup_screen.dart';
import 'package:islamic_app/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (kIsWeb) {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyAkc-Hl4-hz5ItCK2jgz--z2tBXWhnfeUw",
        appId: "1:1234567890:web:abcdefgh12345678", // 🔁 Replace this
        messagingSenderId: "1234567890",              // 🔁 Replace this
        projectId: "your-project-id",                 // 🔁 Replace this
        authDomain: "your-project-id.firebaseapp.com", // (Optional for web)
        storageBucket: "your-project-id.appspot.com",  // (Optional)
      ),
    );
  } else {
    await Firebase.initializeApp();
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quran App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const  IntroSplashScreen(),
      routes: {
        '/login': (_) => const LoginScreen(),
        '/signup': (_) => const SignupScreen(),
        '/home': (_) => HomeScreen(),
      },
    );
  }
}
