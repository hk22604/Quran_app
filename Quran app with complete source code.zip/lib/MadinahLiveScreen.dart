import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:io';

class MadinahLiveScreen extends StatefulWidget {
  @override
  _MadinahLiveScreenState createState() => _MadinahLiveScreenState();
}

class _MadinahLiveScreenState extends State<MadinahLiveScreen> {
  bool isLoading = true;
  late final WebViewController _controller;
  final String madinahUrl = 'https://youtu.be/-jWCvRuC254';

  @override
  void initState() {
    super.initState();

    final PlatformWebViewControllerCreationParams params =
    const PlatformWebViewControllerCreationParams();

    _controller = WebViewController.fromPlatformCreationParams(params)
      ..loadRequest(Uri.parse(madinahUrl))
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          setState(() {
            isLoading = false;
          });
        },
      ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Live from Madinah"),
        backgroundColor: Colors.teal,
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (isLoading)
            Center(child: CircularProgressIndicator(color: Colors.teal)),
        ],
      ),
    );
  }
}
