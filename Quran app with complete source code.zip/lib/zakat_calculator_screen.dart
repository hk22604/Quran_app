import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ZakatCalculatorScreen extends StatefulWidget {
  @override
  _ZakatCalculatorScreenState createState() => _ZakatCalculatorScreenState();
}

class _ZakatCalculatorScreenState extends State<ZakatCalculatorScreen> {
  final TextEditingController _goldController = TextEditingController();
  final TextEditingController _cashController = TextEditingController();

  double zakatAmount = 0.0;

  @override
  void initState() {
    super.initState();
    _loadSavedData();
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    _goldController.text = prefs.getDouble('gold')?.toString() ?? '';
    _cashController.text = prefs.getDouble('cash')?.toString() ?? '';
    setState(() {
      zakatAmount = prefs.getDouble('zakat') ?? 0.0;
    });
  }

  Future<void> calculateZakat() async {
    final prefs = await SharedPreferences.getInstance();
    final gold = double.tryParse(_goldController.text) ?? 0.0;
    final cash = double.tryParse(_cashController.text) ?? 0.0;
    final total = gold + cash;
    final zakat = total * 0.025;

    await prefs.setDouble('gold', gold);
    await prefs.setDouble('cash', cash);
    await prefs.setDouble('zakat', zakat);

    setState(() {
      zakatAmount = zakat;
    });
  }

  @override
  Widget build(BuildContext context) {
    final Color primaryGreen = Color(0xFF2E7D32); // Darker green
    final Color lightGreen = Color(0xFFE8F5E9); // Soft green background

    return Scaffold(
      backgroundColor: lightGreen,
      appBar: AppBar(
        title: Text("Zakat Calculator"),
        backgroundColor: primaryGreen,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: _goldController,
              decoration: InputDecoration(
                labelText: "Gold Value (PKR)",
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            TextField(
              controller: _cashController,
              decoration: InputDecoration(
                labelText: "Cash (PKR)",
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: calculateZakat,
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryGreen,
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                "Calculate Zakat",
                style: TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
            SizedBox(height: 24),
            Text(
              "Zakat to Pay: Rs. ${zakatAmount.toStringAsFixed(2)}",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: primaryGreen,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
