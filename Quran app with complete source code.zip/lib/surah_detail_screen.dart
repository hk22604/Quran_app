import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:dio/dio.dart';
import 'surah_audio_player_screen.dart';

class SurahDetailScreen extends StatefulWidget {
  final int surahNumber;
  final String surahName;
  final int? initialAyah;

  SurahDetailScreen({
    required this.surahNumber,
    required this.surahName,
    this.initialAyah,
  });

  @override
  _SurahDetailScreenState createState() => _SurahDetailScreenState();
}

class _SurahDetailScreenState extends State<SurahDetailScreen> {
  List ayahs = [];
  bool isLoading = true;

  Set<String> bookmarkedAyahs = {};
  Map<String, String> downloadedAudioPaths = {};

  late AudioPlayer audioPlayer;
  int currentPlayingIndex = -1;
  bool isPlayingFullSurah = false;

  bool isDownloading = false;
  double downloadProgress = 0.0;
  double downloadedSizeMB = 0.0;

  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    audioPlayer = AudioPlayer();
    _scrollController = ScrollController();
    fetchSurahDetails();
    loadBookmarks();
    loadDownloadedAyahs();

    audioPlayer.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed &&
          isPlayingFullSurah) {
        if (currentPlayingIndex < ayahs.length - 1) {
          playAyahAtIndex(currentPlayingIndex + 1);
        } else {
          setState(() {
            isPlayingFullSurah = false;
            currentPlayingIndex = -1;
          });
        }
      }
    });
  }

  @override
  void dispose() {
    audioPlayer.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> fetchSurahDetails() async {
    final resp = await http.get(Uri.parse(
        'https://api.quran.gading.dev/surah/${widget.surahNumber}'));

    if (resp.statusCode == 200) {
      final data = json.decode(resp.body);
      setState(() {
        ayahs = data['data']['verses'];
        isLoading = false;
      });
      if (widget.initialAyah != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          scrollToAyah(widget.initialAyah!);
        });
      }
    } else {
      throw Exception('Failed to load Surah details');
    }
  }

  void scrollToAyah(int ayahNum) {
    final idx = ayahs.indexWhere((a) => a['number']['inSurah'] == ayahNum);
    if (idx >= 0) {
      _scrollController.animateTo(
        idx * 140.0,
        duration: Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  Future<void> loadBookmarks() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      bookmarkedAyahs = (prefs.getStringList('bookmarks') ?? []).toSet();
    });
  }

  Future<void> toggleBookmark(String key) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      bookmarkedAyahs.contains(key)
          ? bookmarkedAyahs.remove(key)
          : bookmarkedAyahs.add(key);
      prefs.setStringList('bookmarks', bookmarkedAyahs.toList());
    });
  }

  Future<void> saveDownloadedAyah(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList('downloaded_ayahs') ?? [];
    if (!list.contains(key)) {
      list.add(key);
      prefs.setStringList('downloaded_ayahs', list);
    }
  }

  Future<void> loadDownloadedAyahs() async {
    final prefs = await SharedPreferences.getInstance();
    final setd = (prefs.getStringList('downloaded_ayahs') ?? []).toSet();
    final dir = await getApplicationDocumentsDirectory();
    setState(() {
      downloadedAudioPaths = {
        for (var a in ayahs)
          if (setd.contains(
              '${widget.surahNumber}:${a['number']['inSurah']}'))
            '${widget.surahNumber}:${a['number']['inSurah']}':
            '${dir.path}/surah_${widget.surahNumber}_ayah_${a['number']['inSurah']}.mp3'
      };
    });
  }

  Future<String?> _downloadAudio(String url, String name) async {
    try {
      final st = await Permission.storage.request();
      if (!st.isGranted) return null;

      final dir = await getApplicationDocumentsDirectory();
      final fp = '${dir.path}/$name.mp3';
      final file = File(fp);

      if (file.existsSync()) return fp;

      final resp = await Dio().get(url, options: Options(responseType: ResponseType.bytes));
      await file.writeAsBytes(resp.data);

      return fp;
    } catch (e) {
      print('Download error: $e');
      return null;
    }
  }

  Future<void> playAyahAtIndex(int idx) async {
    if (idx < 0 || idx >= ayahs.length) return;
    final a = ayahs[idx];
    final rn = a['number']['inSurah'];
    final key = '${widget.surahNumber}:$rn';
    final url = a['audio']['primary'] ?? '';

    String? path = downloadedAudioPaths[key];
    if (path == null && url.isNotEmpty) {
      path = await _downloadAudio(url, 'surah_${widget.surahNumber}_ayah_$rn');
      if (path != null) {
        downloadedAudioPaths[key] = path;
        await saveDownloadedAyah(key);
      }
    }

    try {
      await audioPlayer.setUrl(path ?? url);
      audioPlayer.play();
      setState(() {
        currentPlayingIndex = idx;
        isPlayingFullSurah = true;
      });
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to play audio')),
      );
    }
  }

  Future<void> downloadAllAyahsAudio() async {
    final st = await Permission.storage.request();
    if (!st.isGranted) return;

    setState(() {
      isDownloading = true;
      downloadProgress = 0;
      downloadedSizeMB = 0;
    });

    final total = ayahs.length;
    int done = 0;
    double size = 0;
    final dir = await getApplicationDocumentsDirectory();

    for (final a in ayahs) {
      final rn = a['number']['inSurah'];
      final key = '${widget.surahNumber}:$rn';
      final url = a['audio']['primary'] ?? '';

      if (!downloadedAudioPaths.containsKey(key) && url.isNotEmpty) {
        try {
          final resp = await Dio().get(url, options: Options(responseType: ResponseType.bytes));
          final fp = '${dir.path}/surah_${widget.surahNumber}_ayah_$rn.mp3';
          await File(fp).writeAsBytes(resp.data);
          downloadedAudioPaths[key] = fp;
          await saveDownloadedAyah(key);

          size += resp.data.length / (1024 * 1024);
        } catch (e) {
          print('Failed ayah $rn: $e');
        }
      }

      done++;
      setState(() {
        downloadProgress = done / total;
        downloadedSizeMB = size;
      });
    }

    setState(() => isDownloading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Downloaded ${downloadedSizeMB.toStringAsFixed(1)} MB')),
    );
  }

  void stopFullSurahPlayback() {
    audioPlayer.stop();
    setState(() {
      isPlayingFullSurah = false;
      currentPlayingIndex = -1;
    });
  }

  @override
  Widget build(BuildContext context) {
    final primaryGreen = Color(0xFF2E7D32);
    final cardGreen = Color(0xFFF1FDF3);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.surahName),
        backgroundColor: primaryGreen,
        actions: [
          IconButton(
            icon: Icon(Icons.library_music_outlined),
            tooltip: "Surah Audio Mode",
            onPressed: () {
              final urls = ayahs
                  .map<String>((a) => a['audio']['primary'] ?? '')
                  .toList();
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SurahAudioPlayerScreen(
                    surahName: widget.surahName,
                    audioUrls: urls,
                  ),
                ),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.download),
            tooltip: "Download Surah Audio",
            onPressed:
            isDownloading || ayahs.isEmpty ? null : downloadAllAyahsAudio,
          ),
          if (isDownloading)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  value: downloadProgress,
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              ),
            ),
          isPlayingFullSurah
              ? IconButton(
            icon: Icon(Icons.stop),
            tooltip: "Stop Full Surah Playback",
            onPressed: stopFullSurahPlayback,
          )
              : IconButton(
            icon: Icon(Icons.play_arrow),
            tooltip: "Play Full Surah",
            onPressed:
            ayahs.isEmpty ? null : () => playAyahAtIndex(0),
          ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: primaryGreen))
          : Column(
        children: [
          if (isDownloading)
            Padding(
              padding: EdgeInsets.all(8),
              child: Text(
                "${(downloadProgress * 100).toStringAsFixed(0)}% — ${downloadedSizeMB.toStringAsFixed(1)} MB downloaded",
                style: TextStyle(fontSize: 14),
              ),
            ),
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: ayahs.length,
              padding: EdgeInsets.all(16),
              itemBuilder: (context, index) {
                final a = ayahs[index];
                final rn = a['number']['inSurah'];
                final key = '${widget.surahNumber}:$rn';
                final downloaded = downloadedAudioPaths.containsKey(key);
                final isPlaying = index == currentPlayingIndex;

                return Card(
                  color: cardGreen,
                  elevation: 2,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                a['text']['arab'],
                                textAlign: TextAlign.right,
                                style: TextStyle(
                                  fontFamily: 'Amiri',
                                  fontSize: 24,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                            Icon(
                              downloaded
                                  ? Icons.check_circle
                                  : Icons.cloud_download,
                              color: downloaded
                                  ? primaryGreen
                                  : Colors.grey,
                            ),
                            SizedBox(width: 8),
                            IconButton(
                              icon: Icon(
                                bookmarkedAyahs.contains(key)
                                    ? Icons.bookmark
                                    : Icons.bookmark_border,
                                color: bookmarkedAyahs.contains(key)
                                    ? primaryGreen
                                    : Colors.grey,
                              ),
                              onPressed: () => toggleBookmark(key),
                            ),
                            IconButton(
                              icon: Icon(
                                isPlaying
                                    ? Icons.pause_circle_filled
                                    : Icons.play_circle_fill,
                                size: 32,
                                color: primaryGreen,
                              ),
                              onPressed: () {
                                if (isPlaying) {
                                  stopFullSurahPlayback();
                                } else {
                                  playAyahAtIndex(index);
                                }
                              },
                            ),
                          ],
                        ),
                        SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Ayah $rn • Page ${a['meta']['page']}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[700],
                            ),
                          ),
                        ),
                        SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            a['translation']['en'] ?? 'No translation.',
                            textAlign: TextAlign.right,
                            style: TextStyle(
                              fontSize: 16,
                              fontStyle: FontStyle.italic,
                              color: Colors.grey[800],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
