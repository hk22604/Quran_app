import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DuasScreen extends StatefulWidget {
  @override
  _DuasScreenState createState() => _DuasScreenState();
}

class _DuasScreenState extends State<DuasScreen> {
  final List<Map<String, String>> duas = [
    {'id': '1', 'title': 'Morning Dua', 'arabic': 'اللّهـمَّ أَنْتَ رَبِّـي لا إلهَ إلاّ أَنْتَ...', 'translation': 'O Allah, You are my Lord, none has the right to be worshipped but You...'},
    {'id': '2', 'title': 'Before Sleeping', 'arabic': 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', 'translation': 'In Your name, O Allah, I die and I live.'},
    {'id': '3', 'title': 'Entering Home', 'arabic': 'اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلِجِ وَخَيْرَ الْمَخْرَجِ', 'translation': 'O Allah, I ask You for a good entrance and a good exit.'},
    {'id': '4', 'title': 'Before Eating', 'arabic': 'بِسْمِ اللهِ', 'translation': 'In the name of Allah.'},
    {'id': '5', 'title': 'After Eating', 'arabic': 'الْـحَمْـدُ للهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ', 'translation': 'All praise is for Allah who fed me this and gave it to me.'},
    {'id': '6', 'title': 'Leaving Home', 'arabic': 'بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ', 'translation': 'In the name of Allah, I place my trust in Allah.'},
    {'id': '7', 'title': 'Entering Mosque', 'arabic': 'اللّهُـمَّ افْتَـحْ لي أَبْوابَ رَحْمَـتِـك', 'translation': 'O Allah, open the gates of Your mercy for me.'},
    {'id': '8', 'title': 'Leaving Mosque', 'arabic': 'اللّهُـمَّ إِنِّي أَسْأَلُـكَ مِنْ فَضْلِـك', 'translation': 'O Allah, I ask You from Your bounty.'},
    {'id': '9', 'title': 'Travel Dua', 'arabic': 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ', 'translation': 'Glory to Him Who has subjected this to us, and we could never have accomplished it.'},
    {'id': '10', 'title': 'Upon Hearing Good News', 'arabic': 'الْـحَمْـدُ للهِ', 'translation': 'All praise is for Allah.'},
    {'id': '11', 'title': 'When Sneezing', 'arabic': 'الْـحَمْـدُ للهِ', 'translation': 'All praise is for Allah.'},
    {'id': '12', 'title': 'Reply to Sneezer', 'arabic': 'يَرْحَمُكَ اللَّهُ', 'translation': 'May Allah have mercy on you.'},
    {'id': '13', 'title': 'When Angry', 'arabic': 'أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ', 'translation': 'I seek refuge with Allah from the accursed devil.'},
    {'id': '14', 'title': 'Before Studying', 'arabic': 'رَبِّ زِدْنِي عِلْمًا', 'translation': 'My Lord, increase me in knowledge.'},
    {'id': '15', 'title': 'After Waking Up', 'arabic': 'الْـحَمْـدُ للهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا', 'translation': 'All praise is for Allah who gave us life after death.'},
    {'id': '16', 'title': 'Protection from Evil', 'arabic': 'اللَّهُمَّ اكْفِنِيهمْ بِمَا شِئْتَ', 'translation': 'O Allah, protect me from them however You wish.'},
    {'id': '17', 'title': 'Rain Dua', 'arabic': 'اللّهُـمَّ صَيِّـباً نافِـعاً', 'translation': 'O Allah, make it beneficial rain.'},
    {'id': '18', 'title': 'Looking in the Mirror', 'arabic': 'اللّهُـمَّ كَمَا حَسَّنْتَ خَلْقِي فَحَسِّنْ خُلُقِي', 'translation': 'O Allah, as You have beautified my appearance, beautify my character.'},
    {'id': '19', 'title': 'Entering Toilet', 'arabic': 'اللّهُـمَّ إِنِّي أَعـوذُ بِكَ مِنَ الْخُبْثِ وَالْخَبَائِثِ', 'translation': 'O Allah, I seek refuge in You from filth and evil creatures.'},
    {'id': '20', 'title': 'Leaving Toilet', 'arabic': 'غُفْرَانَكَ', 'translation': 'I ask You (Allah) for forgiveness.'},
  ];

  Set<String> favoriteIds = Set();

  @override
  void initState() {
    super.initState();
    loadFavorites();
  }

  Future<void> loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      favoriteIds = prefs.getStringList('favorite_duas')?.toSet() ?? {};
    });
  }

  Future<void> toggleFavorite(String id) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (favoriteIds.contains(id)) {
        favoriteIds.remove(id);
      } else {
        favoriteIds.add(id);
      }
    });
    await prefs.setStringList('favorite_duas', favoriteIds.toList());
  }

  final Color primaryColor = Color(0xFF2E7D32); // Dark green
  final Color cardColor = Color(0xFFC8E6C9); // Light green

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Duas & Azkar"),
        backgroundColor: primaryColor,
      ),
      body: ListView.builder(
        itemCount: duas.length,
        padding: EdgeInsets.all(12),
        itemBuilder: (context, index) {
          final dua = duas[index];
          final isFavorite = favoriteIds.contains(dua['id']);

          return TweenAnimationBuilder(
            duration: Duration(milliseconds: 500 + index * 100),
            tween: Tween<double>(begin: 0, end: 1),
            builder: (context, value, child) {
              return Opacity(
                opacity: value,
                child: Transform.translate(
                  offset: Offset(0, 30 * (1 - value)),
                  child: child,
                ),
              );
            },
            child: Card(
              color: cardColor.withOpacity(0.3),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(dua['title']!, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        IconButton(
                          icon: Icon(
                            isFavorite ? Icons.favorite : Icons.favorite_border,
                            color: isFavorite ? Colors.red : Colors.grey,
                          ),
                          onPressed: () => toggleFavorite(dua['id']!),
                        )
                      ],
                    ),
                    SizedBox(height: 8),
                    Text(dua['arabic']!, textAlign: TextAlign.right, style: TextStyle(fontSize: 20, fontFamily: 'Amiri')),
                    SizedBox(height: 8),
                    Text(dua['translation']!, style: TextStyle(color: Colors.grey[700])),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
