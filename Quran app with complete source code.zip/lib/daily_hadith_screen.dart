// daily_hadith_screen.dart
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class DailyHadithScreen extends StatefulWidget {
  @override
  _DailyHadithScreenState createState() => _DailyHadithScreenState();
}

class _DailyHadithScreenState extends State<DailyHadithScreen> {
  List<dynamic> _hadithList = [];
  String? _randomHadith;

  @override
  void initState() {
    super.initState();
    loadHadiths();
  }

  Future<void> loadHadiths() async {
    final String response = await rootBundle.loadString('assets/hadiths.json');
    final List<dynamic> data = json.decode(response);
    setState(() {
      _hadithList = data;
      _randomHadith = _hadithList[Random().nextInt(_hadithList.length)];
    });
  }

  void _showNewHadith() {
    setState(() {
      _randomHadith = _hadithList[Random().nextInt(_hadithList.length)];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF0F9FF),
      appBar: AppBar(
        title: Text("Daily Hadith"),
        backgroundColor: Color(0xFF006D77),
      ),
      body: _randomHadith == null
          ? Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.menu_book, color: Color(0xFF006D77), size: 50),
            SizedBox(height: 20),
            Text(
              _randomHadith!,
              style: TextStyle(fontSize: 18, color: Colors.black87, height: 1.4),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: _showNewHadith,
              icon: Icon(Icons.refresh),
              label: Text("Show Another Hadith"),
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF83C5BE)),
            )
          ],
        ),
      ),
    );
  }
}
