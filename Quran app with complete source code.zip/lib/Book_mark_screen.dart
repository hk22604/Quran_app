import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

import 'surah_detail_screen.dart'; // Import your SurahDetailScreen

class BookmarksScreen extends StatefulWidget {
  @override
  _BookmarksScreenState createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  List<Map<String, dynamic>> bookmarkedAyahs = [];

  final Color primaryColor = const Color(0xFF2E7D32); // Green
  final Color secondaryColor = const Color(0xFF81C784); // Light Green

  @override
  void initState() {
    super.initState();
    loadBookmarks();
  }

  Future<void> loadBookmarks() async {
    final prefs = await SharedPreferences.getInstance();
    final savedBookmarks = prefs.getStringList('bookmarks') ?? [];

    setState(() {
      bookmarkedAyahs = savedBookmarks.map((e) {
        final parts = e.split(':');
        return {
          'surahNumber': int.parse(parts[0]),
          'ayahNumber': int.parse(parts[1]),
          'ayah': parts.length > 2 ? parts[2] : 'Ayah text',
          'surah': parts.length > 3 ? parts[3] : 'Surah',
          'page': parts.length > 4 ? parts[4] : 'Page',
        };
      }).toList();
    });
  }

  Future<void> removeBookmark(String surahNumber, int ayahNumber) async {
    final prefs = await SharedPreferences.getInstance();
    final savedBookmarks = prefs.getStringList('bookmarks') ?? [];

    savedBookmarks.removeWhere((e) => e.startsWith('$surahNumber:$ayahNumber'));
    await prefs.setStringList('bookmarks', savedBookmarks);
    loadBookmarks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bookmarked Ayahs'),
        backgroundColor: primaryColor,
      ),
      body: bookmarkedAyahs.isEmpty
          ? const Center(
        child: Text('No bookmarks found'),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: bookmarkedAyahs.length,
        itemBuilder: (context, index) {
          final ayah = bookmarkedAyahs[index];
          return Card(
            color: secondaryColor.withOpacity(0.1),
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              title: Text(
                ayah['ayah'],
                textAlign: TextAlign.right,
                style: const TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 22,
                  color: Colors.black87,
                ),
              ),
              subtitle: Text(
                '${ayah['surah']} - Ayah ${ayah['ayahNumber']} - Page ${ayah['page']}',
                style: TextStyle(color: Colors.grey[700]),
              ),
              trailing: IconButton(
                icon: const Icon(Icons.delete, color: Colors.redAccent),
                onPressed: () {
                  removeBookmark(
                    ayah['surahNumber'].toString(),
                    ayah['ayahNumber'],
                  );
                },
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SurahDetailScreen(
                      surahNumber: ayah['surahNumber'],
                      surahName: ayah['surah'],
                      initialAyah: ayah['ayahNumber'],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
