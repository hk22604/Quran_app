import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'surah_detail_screen.dart';
import 'quran_data.dart'; // Arabic Surah names list

class JuzzIndexScreen extends StatefulWidget {
  @override
  _JuzzIndexScreenState createState() => _JuzzIndexScreenState();
}

class _JuzzIndexScreenState extends State<JuzzIndexScreen> {
  List surahs = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchSurahs();
  }

  Future<void> fetchSurahs() async {
    final url = Uri.parse('https://api.quran.gading.dev/surah');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          surahs = data['data'];
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final primaryGreen = Color(0xFF2E7D32); // Islamic dark green
    final lightBackground = Color(0xFFF1FDF3); // Soft green-tinted background

    return Scaffold(
      backgroundColor: lightBackground,
      appBar: AppBar(
        title: Text('Juzz Index'),
        backgroundColor: primaryGreen,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: primaryGreen))
          : ListView.builder(
        itemCount: surahs.length,
        itemBuilder: (context, index) {
          final surah = surahs[index];
          return Card(
            color: Colors.white,
            elevation: 2,
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              contentPadding:
              EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              leading: CircleAvatar(
                backgroundColor: primaryGreen,
                child: Text(
                  '${surah['number']}',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              title: Text(
                quranSurahArabicNames[surah['number'] - 1],
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 22,
                  fontFamily: 'Amiri',
                  color: Colors.black,
                ),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 4),
                  Text(
                    '${surah['name']['transliteration']['en']} — ${surah['revelation']['en']}',
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.grey[800],
                    ),
                  ),
                ],
              ),
              trailing: Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.grey[600],
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SurahDetailScreen(
                      surahNumber: surah['number'],
                      surahName:
                      quranSurahArabicNames[surah['number'] - 1],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
